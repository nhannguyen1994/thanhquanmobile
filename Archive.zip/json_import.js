{
    "Màn hình" : {
        "Công nghệ màn hình" : "Công nghệ màn hình",
        "Độ phân giải" : "Full HD (1080 x 1920 pixels)",
        "Màn hình rộng" : "5.5",
        "Mặt kính cảm ứng" : "Kính oleophobic (ion cường lực)"
    },
    "Camera sau" : {
        "Độ phân giải" : "Hai camera 12 MP",
        "Quay phim" : "4K 2160p@30fps",
        "Đèn Flash" : "4 đèn LED (2 tông màu)",
        "Chụp ảnh nâng cao" : "Chạm lấy nét, Panorama, Chống rung quang học (OIS), Tự động lấy nét, Nhận diện khuôn mặt, HDR"
    },
    "Camera trước" : {
        "Độ phân giải" : "7 MP",
        "Videocall" : "Hỗ trợ VideoCall thông qua ứng dụng OTT",
        "Thông tin khác" : "Nhận diện khuôn mặt, Quay video Full HD, Tự động lấy nét, Selfie ngược sáng HDR"
    },
    "Hệ điều hành - CPU" : {
        "Hệ điều hành" : "iOS 10",
        "Chipset (hãng SX CPU)" : "Apple A10 Fusion 4 nhân 64-bit",
        "Tốc độ CPU" : "2.3 GHz",
        "Chip đồ họa (GPU)" : "PowerVR Series7XT Plus"
    },
    "Bộ nhớ & Lưu trữ" : {
        "RAM" : "3 GB",
        "Bộ nhớ trong" : "256 GB",
        "Bộ nhớ còn lại (khả dụng)" : "Khoảng 247.52 GB",
        "Thẻ nhớ ngoài" : "Không"
    },
    "Kết nối" : {
        "Mạng di động" : "3G, 4G LTE Cat 9",
        "SIM" : "1 Nano SIM",
        "Wifi" : "Wi-Fi 802.11 a/b/g/n/ac, Dual-band, Wi-Fi hotspot",
        "GPS" : "A-GPS, GLONASS",
        "Bluetooth" : "A2DP, LE, v4.2",
        "Cổng kết nối/sạc" : "Lightning",
        "Jack tai nghe" : "Không",
        "Kết nối khác" : "NFC, Air Play, HDMI, OTG"
    }
}