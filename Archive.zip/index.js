'use strict';
const {db, config} = require('./pgp');
const express = require('express');
const app = express();
const nunjucks = require('nunjucks');
const expressNunjucks = require('express-nunjucks');
const Products = require('./route/products.js');

let log = console.log;

nunjucks.configure('views', {
  autoescape: true,
  express   : app,
  cache : false
});

/* Create Arr Products */
let p_arr = [];
const createProduct = (product_id, product_name, manufacturer_id, price, quantity, description, properties, madein, promotion, status, created_at) => {
   let product = new Products(product_id, product_name, manufacturer_id, price, quantity, description, properties, madein, promotion, status, created_at);
   p_arr.push(product);
};

createProduct('IP7P256', 'Điện thoại iPhone 7 Plus 256GB', '', '24990000', '12', '', '{"Màn hình":{"Công nghệ màn hình":"Công nghệ màn hình","Độ phân giải":"Full HD (1080 x 1920 pixels)","Màn hình rộng":"5.5","Mặt kính cảm ứng":"Kính oleophobic (ion cường lực)"},"Camera sau":{"Độ phân giải":"Hai camera 12 MP","Quay phim":"4K 2160p@30fps","Đèn Flash":"4 đèn LED (2 tông màu)","Chụp ảnh nâng cao":"Chạm lấy nét, Panorama, Chống rung quang học (OIS), Tự động lấy nét, Nhận diện khuôn mặt, HDR"},"Camera trước":{"Độ phân giải":"7 MP","Videocall":"Hỗ trợ VideoCall thông qua ứng dụng OTT","Thông tin khác":"Nhận diện khuôn mặt, Quay video Full HD, Tự động lấy nét, Selfie ngược sáng HDR"},"Hệ điều hành - CPU":{"Hệ điều hành":"iOS 10","Chipset (hãng SX CPU)":"Apple A10 Fusion 4 nhân 64-bit","Tốc độ CPU":"2.3 GHz","Chip đồ họa (GPU)":"PowerVR Series7XT Plus"},"Bộ nhớ & Lưu trữ":{"RAM":"3 GB","Bộ nhớ trong":"256 GB","Bộ nhớ còn lại (khả dụng)":"Khoảng 247.52 GB","Thẻ nhớ ngoài":"Không"},"Kết nối":{"Mạng di động":"3G, 4G LTE Cat 9","SIM":"1 Nano SIM","Wifi":"Wi-Fi 802.11 a/b/g/n/ac, Dual-band, Wi-Fi hotspot","GPS":"A-GPS, GLONASS","Bluetooth":"A2DP, LE, v4.2","Cổng kết nối/sạc":"Lightning","Jack tai nghe":"Không","Kết nối khác":"NFC, Air Play, HDMI, OTG"}}', '', '', '', '2017-04-07 09:00:00');



app.engine('html', nunjucks.render);

app.set('view engine', 'html');

app.use(express.static(__dirname + '/public'));


app.get('/', function(req, res) {
    log(p_arr);
    res.render('index.njk', {title : 'Home', products : Products.all(p_arr)});
    /*
    db.query('SELECT * FROM product')
    .then(data => {
        res.render('index.njk', {title : 'Home', products : data});
    })
    .catch(error => {
        log(error);
    });
    */
});

app.get('/products', function(req, res) {
    db.query('SELECT * FROM product')
    .then(data => {
        res.render('products.njk', {title : 'Products', products : data});
    })
    .catch(error => {
        log(error);
    });

});

app.get('/product/detail/:id', function(req, res) {
    let id = req.params.id;
    db.query('SELECT * FROM product WHERE product_id = $1', id)
    .then(data => {
        res.render('detail.njk', {title : data.product_name, detail : data});
    })
    .catch(error => {
        log(error);
    });

});

app.get('/test', function(req, res) {
    let data = ['a', 'b', 'c', 'd', 'e'];
    res.render('test.html', {title: 'Title', data : data});
});

app.get('/test2', function(req, res) {
    let data = ['a', 'b', 'c', 'd', 'e', 'f'];
    res.render('test2.html', {title: 'Title2', data : data});
});

const port = 3000;
app.listen(port, () => {
    console.log('Ready for GET requests on http://localhost:' + port);
});
