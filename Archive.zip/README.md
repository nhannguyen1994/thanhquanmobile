#Product Template
##usage
``` 
yarn
```
##Run
``` 
node index

http://localhost:3000/products
```


