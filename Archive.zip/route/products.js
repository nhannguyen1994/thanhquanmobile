const {db,} = require('../pgp');

class Products {

  constructor(product_id, product_name, manufacturer_id, price, quantity, description, properties, madein, promotion, status, created_at ) {  //Use ES6 optional parameter
    this.product_id = product_id;
    this.product_name = product_name;
    this.manufacturer_id = manufacturer_id;
    this.price = price;
    this.quantity = quantity;
    this.description = description;
    this.properties = properties;
    this.madein = madein;
    this.promotion = promotion;
    this.status = status;
    this.created_at = created_at;
  }

  static all(p_arr) {
    return p_arr;
  }

  static findById(id) {
    return db.one("SELECT * FROM cms.class WHERE id = $1", [id])
      .then(data => {
        return new Class(data.name, data.id);
      })
      .catch(error => {
        return error;
      })
  }

  /**
   * Search class by name exact or like
   * @param {string} name
   * @param {string} operator can be either = or LIKE
   * @returns {Promise.<T>}
   */
  static findByName(name, operator) {

    let query;

    switch (operator) {
      case "=":
        query = "SELECT * FROM cms.class WHERE name = $1";
        break;
      case "LIKE":
        query = "SELECT * FROM cms.class WHERE name LIKE '%$1#%'";
        break;
    }

    return db.one(query, [name])
      .then(data => {
        return new Class(data.name, data.id);
      })
      .catch(error => {
        return error;
      })
  }
}

module.exports = Products;